package com.ebo.lamode.models

class Banner(val id: String, val text: String, val imageUrl: String, val linkUrl: String) {
    constructor() : this("", "", "", "")
}