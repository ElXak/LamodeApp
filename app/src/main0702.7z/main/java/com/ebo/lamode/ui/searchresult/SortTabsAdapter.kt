package com.ebo.lamode.ui.searchresult

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.ebo.lamode.R
import com.ebo.lamode.SearchResultActivity

private val TAB_TITLES = arrayOf(
    R.string.search_result_tab_best_match,
    R.string.search_reslut_tab_top_rated,
    R.string.search_reslut_tab_price_lowHigh,
    R.string.search_reslut_tab_price_highLow
)

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */

class SortTabsAdapter(private val context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {

    override fun getItem(position: Int): Fragment {
        // getItem is called to instantiate the fragment for the given page.
        // Return a SearchResultFragment (defined as a static inner class below).
        //return SearchResultFragment.newInstance(position + 1)
        val viewParams: MutableMap<String, String>? = mutableMapOf("columnCount" to "2", "orientation" to "vertical")
        val filterParams: MutableMap<String, String>? = mutableMapOf("setFilter" to "no")
        var sortParams: MutableMap<String, String>? = mutableMapOf("setSort" to "no")

        when (position) {
            1 -> sortParams = mutableMapOf("setSort" to "no")
            2 -> sortParams = mutableMapOf("setSort" to "rating")
            3 -> sortParams = mutableMapOf("setSort" to "priceAsc")
            4 -> sortParams = mutableMapOf("setSort" to "priceDesc")
        }

        return SearchResultFragment.newInstance(viewParams, SearchResultActivity.categoryId!!, filterParams, sortParams)
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return context.resources.getString(TAB_TITLES[position])
    }

    override fun getCount(): Int {
        // Show 4 total pages.
        return 4
    }
}