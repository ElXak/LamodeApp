package com.ebo.lamode.ui.main

import android.content.Context
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.ebo.lamode.R
import com.ebo.lamode.SearchResultActivity

private val TAB_TITLES = arrayOf(
    R.string.tab_best_match,
    R.string.tab_top_rated,
    R.string.tab_price_lowHigh,
    R.string.tab_price_highLow
)

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
class SectionsPagerAdapter(private val context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {

    override fun getItem(position: Int): Fragment {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).
        //return PlaceholderFragment.newInstance(position + 1)
        val viewParams: MutableMap<String, String>? = mutableMapOf("columnCount" to "2", "orientation" to "vertical")
        val filterParams: MutableMap<String, String>? = mutableMapOf("setFilter" to "no")
        var sortParams: MutableMap<String, String>? = mutableMapOf("setSort" to "no")

        when (position) {
            1 -> sortParams = mutableMapOf("setSort" to "no")
            2 -> sortParams = mutableMapOf("setSort" to "rating")
            3 -> sortParams = mutableMapOf("setSort" to "priceAsc")
            4 -> sortParams = mutableMapOf("setSort" to "priceDesc")
        }

        return PlaceholderFragment.newInstance(viewParams, SearchResultActivity.categoryId!!, filterParams, sortParams)
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return context.resources.getString(TAB_TITLES[position])
    }

    override fun getCount(): Int {
        // Show 4 total pages.
        return 4
    }
}