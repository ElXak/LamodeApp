package com.ebo.lamode

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.text.Layout
import android.view.*
import android.widget.Toast
import android.widget.SearchView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.ebo.lamode.models.Product
import com.ebo.lamode.views.SearchResultAdapter
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.content_search_result.*

class SearchResultFragment : Fragment() {

    private var viewParams: MutableMap<String, String>? = null
    private var categoryId = "1"
    //interface viewParams<Name, Value> : Map<Name, Value>
    private var filterParams: MutableMap<String, String>? = null
    private var listener: OnFragmentInteractionListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

        arguments?.let {
            viewParams = ARG_VIEW_PARAMS
            categoryId = it.getString(ARG_CATEGORY_ID)!!
            filterParams = ARG_FILTER_PARAMS
        }
    }

    //@SuppressLint("WrongConstant")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_search_result, container, false)
        val columnCount = viewParams?.get("columnCount").toString().toInt()
        val orientation = viewParams?.get("orientation").toString()

        /*
        val stubView: ViewStub? = activity?.findViewById<ViewStub>(R.id.layout_stub)
        stubView?.layoutResource = R.layout.app_bar_search
        val inflated = stubView?.inflate()
        */

        val recyclerView: RecyclerView = view.findViewById(R.id.searchResult_recyclerView)

        // Set the adapter
        with(recyclerView) {
            layoutManager = when {
                columnCount <= 1 -> {
                    when {
                        orientation.equals("horizontal") -> LinearLayoutManager(context, RecyclerView.HORIZONTAL,false)
                        else -> LinearLayoutManager(context, RecyclerView.VERTICAL,false)
                    }
                }
                else -> GridLayoutManager(context, columnCount)
            }
        }

        // Constructing Categories Section
        val adapter = GroupAdapter<ViewHolder>()
        val requestQueue = Volley.newRequestQueue(activity)

        val url = "http://dars.tj/salespost/search_results.php?catid=$categoryId"

        val jsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
            Response.Listener { response ->
                for (x in 0 until response.length()) {
                    val id = response.getJSONObject(x).getString("id")
                    val name = response.getJSONObject(x).getString("name")
                    val imageUrl = response.getJSONObject(x).getString("imageUrl")
                    val price = response.getJSONObject(x).getString("price").toDouble()
                    val rating = response.getJSONObject(x).getString("rating").toDouble()

                    adapter.add(
                        SearchResultAdapter(
                            Product(id, name, imageUrl, price, rating)
                        )
                    )
                }

                adapter.setOnItemClickListener { item, view ->
                    val searchResult = item as SearchResultAdapter

                    /*
                    if (savedInstanceState == null) {
                        val fragmentTransaction: FragmentTransaction = activity?.supportFragmentManager!!.beginTransaction()
                        fragmentTransaction.replace(
                            R.id.fragment_container,
                            ProductFragment.newInstance(2/*, "filterParams"*/)
                        ).addToBackStack(null).commit()
                    }
                    */
                }

                searchResult_recyclerView.adapter = adapter
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.message, Toast.LENGTH_LONG).show()
            })

        requestQueue.add(jsonArrayRequest)

        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {

        // TODO: Customize parameter argument names
        var ARG_VIEW_PARAMS: MutableMap<String, String>? = mutableMapOf("orientation" to "vertical", "columnCount" to "2")
        const val ARG_CATEGORY_ID = "1"
        var ARG_FILTER_PARAMS: MutableMap<String, String>? = mutableMapOf("setFilter" to "no")

        // TODO: Customize parameter initialization
        @JvmStatic
        fun newInstance(viewParams:MutableMap<String, String>?, categoryId: String, filterParams: MutableMap<String, String>?) =
            SearchResultFragment().apply {
                arguments = Bundle().apply {
                    ARG_VIEW_PARAMS = viewParams
                    putString(ARG_CATEGORY_ID, categoryId)
                    ARG_FILTER_PARAMS = filterParams
                }
            }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.top_search_menu, menu)

        /*
        val searchItem = menu?.findItem(R.id.top_search)
        val searchView = searchItem?.actionView as SearchView
        */

        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.top_filter -> true
            else -> super.onOptionsItemSelected(item)
        }

        /*
        when (item.itemId) {
            R.id.top_messages -> {
                supportFragmentManager.beginTransaction().replace(R.id.fragment_container, MessagesFragment()).addToBackStack(null).commit()
                //textMessage.setText(R.string.top_messages)
                return true
            }
            R.id.top_notifications -> {
                supportFragmentManager.beginTransaction().replace(R.id.fragment_container, NotificationsFragment()).addToBackStack(null).commit()
                //textMessage.setText(R.string.top_notifications)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
        */
    }

}