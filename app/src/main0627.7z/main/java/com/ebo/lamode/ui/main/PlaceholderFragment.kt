package com.ebo.lamode.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.ebo.lamode.R
import com.ebo.lamode.SearchResultFragment

/**
 * A placeholder fragment containing a simple view.
 */
class PlaceholderFragment : Fragment() {

    private lateinit var pageViewModel: PageViewModel

    private var viewParams: MutableMap<String, String>? = null
    private var categoryId = "1"
    private var filterParams: MutableMap<String, String>? = null
    private var listener: SearchResultFragment.OnFragmentInteractionListener? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

        /*
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel::class.java).apply {
            setIndex(arguments?.getInt(ARG_SECTION_NUMBER) ?: 1)
        }
        */

        arguments?.let {
            viewParams = ARG_VIEW_PARAMS
            categoryId = it.getString(ARG_CATEGORY_ID)!!
            filterParams = ARG_FILTER_PARAMS
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_main, container, false)
        val textView: TextView = root.findViewById(R.id.section_label)
        pageViewModel.text.observe(this, Observer<String> {
            textView.text = it
        })
        return root
    }

    companion object {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        //private const val ARG_SECTION_NUMBER = "section_number"

        // TODO: Customize parameter argument names
        var ARG_VIEW_PARAMS: MutableMap<String, String>? = mutableMapOf("orientation" to "vertical", "columnCount" to "2")
        const val ARG_CATEGORY_ID = "1"
        var ARG_FILTER_PARAMS: MutableMap<String, String>? = mutableMapOf("setFilter" to "no")

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */

        /*
        @JvmStatic
        fun newInstance(sectionNumber: Int): PlaceholderFragment {
            return PlaceholderFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBER, sectionNumber)
                }
            }
        }
        */

        // TODO: Customize parameter initialization
        @JvmStatic
        fun newInstance(viewParams:MutableMap<String, String>?, categoryId: String, filterParams: MutableMap<String, String>?) =
            PlaceholderFragment().apply {
                arguments = Bundle().apply {
                    ARG_VIEW_PARAMS = viewParams
                    putString(ARG_CATEGORY_ID, categoryId)
                    ARG_FILTER_PARAMS = filterParams
                }
            }
    }
}