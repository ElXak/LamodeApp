package com.ebo.lamode.views

import com.ebo.lamode.R
import com.ebo.lamode.models.Banner
import com.squareup.picasso.Picasso
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.item_banners.view.background_imageView
import kotlinx.android.synthetic.main.item_banners.view.text_textView

class BannersAdapter(val banner: Banner): Item<ViewHolder>() {
    var linkUrl: String = banner.linkUrl

    override fun bind(viewHolder: ViewHolder, position: Int) {
        Picasso.get().load(banner.imageUrl).into(viewHolder.itemView.background_imageView)
        viewHolder.itemView.text_textView.text = banner.text
    }

    override fun getLayout(): Int {
        return R.layout.item_banners
    }
}