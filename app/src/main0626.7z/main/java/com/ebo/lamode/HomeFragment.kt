package com.ebo.lamode

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.ebo.lamode.models.Banner
import com.ebo.lamode.models.Category
import com.ebo.lamode.models.Product
import com.ebo.lamode.views.BannersAdapter
import com.ebo.lamode.views.CategoriesAdapter
import com.ebo.lamode.views.ProductsAdapter
import com.ebo.lamode.views.SearchResultAdapter
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.content_home.*
import android.content.Context.LAYOUT_INFLATER_SERVICE
import androidx.core.content.ContextCompat.getSystemService
import android.view.LayoutInflater
import android.widget.RelativeLayout
import androidx.constraintlayout.widget.ConstraintLayout


class HomeFragment : Fragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        /*
        // Retrieve layout:
        val appBarInclude = activity?.findViewById(R.id.appBar_include) as ConstraintLayout

        // Instantiate & use inflater:
        //val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater?
        val layout = inflater.inflate(R.layout.app_bar_main, null)

        // Clear & set new views:
        appBarInclude.removeAllViews()
        appBarInclude.addView(layout)
        */

        /*
        val stubView: ViewStub? = activity?.findViewById<ViewStub>(R.id.layout_stub)
        stubView?.layoutResource = R.layout.app_bar_main
        val inflated = stubView?.inflate()
        */

        // Constructing Categories Section
        val categoriesAdapter = GroupAdapter<ViewHolder>()
        val requestQueue = Volley.newRequestQueue(activity)

        var url = "http://dars.tj/salespost/categories.php"

        val categoriesJsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
            Response.Listener { response ->
                for (x in 0 until response.length()) {
                    val id = response.getJSONObject(x).getString("id")
                    val name = response.getJSONObject(x).getString("name")
                    val imageUrl = response.getJSONObject(x).getString("imageUrl")

                    categoriesAdapter.add(
                        CategoriesAdapter(
                            Category(id, name, imageUrl)
                        )
                    )
                }

                categoriesAdapter.setOnItemClickListener { item, view ->
                    val category = item as CategoriesAdapter

                    if (savedInstanceState == null) {
                        val fragmentTransaction: FragmentTransaction = activity?.supportFragmentManager!!.beginTransaction()
                        var viewParams: MutableMap<String, String>? = mutableMapOf("columnCount" to "2", "orientation" to "vertical")
                        var filterParams: MutableMap<String, String>? = mutableMapOf("setFilter" to "no")

                        fragmentTransaction.replace(
                            R.id.fragment_container,
                            SearchResultFragment.newInstance(viewParams, category.categoryId, filterParams)
                        ).addToBackStack(null).commit()
                    }

                    //Toast.makeText(activity, category.categoryId, Toast.LENGTH_SHORT).show()
                    //val intent = Intent(view.context, ChatLogActivity::class.java)
                    //intent.putExtra(USER_KEY, userItem.user)
                    //startActivity(intent)
                    //finish()
                }

                categories_recyclerView.adapter = categoriesAdapter
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.message, Toast.LENGTH_LONG).show()
            })

        requestQueue.add(categoriesJsonArrayRequest)

        // Constructing Banners Section
        val bannersAdapter = GroupAdapter<ViewHolder>()

        url = "http://dars.tj/salespost/banners.php"

        val bannersJsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
            Response.Listener { response ->
                for (x in 0 until response.length()) {
                    val id = response.getJSONObject(x).getString("id")
                    val text = response.getJSONObject(x).getString("text")
                    val imageUrl = response.getJSONObject(x).getString("imageUrl")
                    val linkUrl = response.getJSONObject(x).getString("linkUrl")

                    bannersAdapter.add(
                        BannersAdapter(
                            Banner(id, text, imageUrl, linkUrl)
                        )
                    )
                }

                bannersAdapter.setOnItemClickListener { item, view ->
                    val banner = item as BannersAdapter
                    Toast.makeText(activity, banner.linkUrl, Toast.LENGTH_SHORT).show()
                    //val intent = Intent(view.context, ChatLogActivity::class.java)
                    //intent.putExtra(USER_KEY, userItem.user)
                    //startActivity(intent)
                    //finish()
                }

                banners_recyclerView.adapter = bannersAdapter
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.message, Toast.LENGTH_LONG).show()
            })

        requestQueue.add(bannersJsonArrayRequest)

        // Constructing Products Section
        val productsAdapter = GroupAdapter<ViewHolder>()

        url = "http://dars.tj/salespost/search_results.php"

        val productsJsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
            Response.Listener { response ->
                for (x in 0 until response.length()) {
                    val id = response.getJSONObject(x).getString("id")
                    val name = response.getJSONObject(x).getString("name")
                    val imageUrl = response.getJSONObject(x).getString("imageUrl")
                    val price = response.getJSONObject(x).getString("price").toDouble()
                    val rating = response.getJSONObject(x).getString("rating").toDouble()

                    productsAdapter.add(
                        ProductsAdapter(
                            Product(id, name, imageUrl, price, rating)
                        )
                    )
                }

                productsAdapter.setOnItemClickListener { item, view ->
                    val products = item as ProductsAdapter

                    //val intent = Intent(view.context, ChatLogActivity::class.java)
                    //intent.putExtra(USER_KEY, userItem.user)
                    //startActivity(intent)
                    //finish()
                }

                products_recyclerView.adapter = productsAdapter
            },
            Response.ErrorListener { error ->
                Toast.makeText(activity, error.message, Toast.LENGTH_LONG).show()
            })

        requestQueue.add(productsJsonArrayRequest)

        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.menu_top, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        /*
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
        */
        val fragmentTransaction: FragmentTransaction = activity?.supportFragmentManager!!.beginTransaction()

        when (item.itemId) {
            R.id.top_messages -> {
                fragmentTransaction.replace(
                    R.id.fragment_container,
                    MessagesFragment()
                ).addToBackStack(null).commit()

                //textMessage.setText(R.string.top_messages)
                return true
            }
            R.id.top_notifications -> {
                fragmentTransaction.replace(
                    R.id.fragment_container,
                    NotificationsFragment()
                ).addToBackStack(null).commit()

                //textMessage.setText(R.string.top_notifications)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }
}