package com.ebo.lamode.models

class Product(val id: String, val name: String, val imageUrl: String, val price: Double, val rating: Double) {
    constructor() : this("", "", "", 0.0, 0.0)
}